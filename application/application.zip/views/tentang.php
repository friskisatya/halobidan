<div class="container">
    <h4 class="title"><i class="fas fa-info-circle"></i>&nbsp Tentang Aplikasi</h4>
    <div class="card-wrapper">
        <div class="card-body">
            <p class="description">
                <?= $rs_tentang[0]->tentang?>
            </p>
        </div>
    </div>
</div>
<!-- end of article -->