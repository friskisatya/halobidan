<div class="card-wrapper">
    <div class="card-img">
        <img class="img-fluid" src="<?= base_url()?>/assets/img/10086.jpg" alt="Card image">
    </div>
    <div class="card-body">
        <h3 class="title text-center" id="layanan">Klinik</h3>
        <hr class="bg-light">
    <div class="row">
        <div class="col-4">
            <div class="card mt-5 ">
                <img class="card-img" src="<?= base_url()?>/assets/img/batuk.jpg" alt="bidan">
                <div class="card-img-overlay d-flex h-10 flex-column justify-content-end p-0">
                    <h5 class="card-title text-center btn-warning">1 Tahun</h5>
                </div>
            </div>
            <div class="card-body mb-5">
            <p class="card-text">nama bidan.</p>
            <p class="card-text">asal klinik.</p>
            <button class="btn btn-sm btn-round btn-primary float-right">chat</button>
            </div>
        </div>
        <div class="col-4">
            <div class="card mt-5 ">
                <img class="card-img" src="<?= base_url()?>/assets/img/batuk.jpg" alt="bidan">
                <div class="card-img-overlay d-flex h-10 flex-column justify-content-end p-0">
                    <h5 class="card-title text-center btn-warning">1 Tahun</h5>
                </div>
            </div>
            <div class="card-body mb-5">
            <p class="card-text">nama bidan.</p>
            <p class="card-text">asal klinik.</p>
            <button class="btn btn-sm btn-round btn-primary float-right">chat</button>
            </div>
        </div>
        <div class="col-4">
            <div class="card mt-5 ">
                <img class="card-img" src="<?= base_url()?>/assets/img/batuk.jpg" alt="bidan">
                <div class="card-img-overlay d-flex h-10 flex-column justify-content-end p-0">
                    <h5 class="card-title text-center btn-warning">1 Tahun</h5>
                </div>
            </div>
            <div class="card-body mb-5">
            <p class="card-text">nama bidan.</p>
            <p class="card-text">asal klinik.</p>
            <button class="btn btn-sm btn-round btn-primary float-right">chat</button>
            </div>
        </div>
        <div class="col-4">
            <div class="card mt-5 ">
                <img class="card-img" src="<?= base_url()?>/assets/img/batuk.jpg" alt="bidan">
                <div class="card-img-overlay d-flex h-10 flex-column justify-content-end p-0">
                    <h5 class="card-title text-center btn-warning">1 Tahun</h5>
                </div>
            </div>
            <div class="card-body mb-5">
            <p class="card-text">nama bidan.</p>
            <p class="card-text">asal klinik.</p>
            <button class="btn btn-sm btn-round btn-primary float-right">chat</button>
            </div>
        </div>
        <div class="col-4">
            <div class="card mt-5 ">
                <img class="card-img" src="<?= base_url()?>/assets/img/batuk.jpg" alt="bidan">
                <div class="card-img-overlay d-flex h-10 flex-column justify-content-end p-0">
                    <h5 class="card-title text-center btn-warning">1 Tahun</h5>
                </div>
            </div>
            <div class="card-body mb-5">
            <p class="card-text">nama bidan.</p>
            <p class="card-text">asal klinik.</p>
            <button class="btn btn-sm btn-round btn-primary float-right">chat</button>
            </div>
        </div>
    </div>
        <hr class="bg-light">
</div>